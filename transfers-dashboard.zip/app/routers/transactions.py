import uuid
from typing import Annotated

from fastapi import APIRouter, Depends, Query, Response, status
from sqlalchemy.orm import Session

from app.core.database import get_db
from app.core.security import CurrentUser
from app.schemas.common import Page
from app.schemas.transaction import (
    OwnTransfersResult,
    TransactionCreate,
    TransactionFilters,
    TransactionRead,
    TransactionUpdate,
    TransferCreate,
    TransferRead,
)
from app.services import change_hooks, own_transfers, transaction_service

router = APIRouter(tags=["Transactions"])
DbSession = Annotated[Session, Depends(get_db)]


@router.get("/transactions", response_model=Page[TransactionRead])
def list_transactions(filters: Annotated[TransactionFilters, Query()], user: CurrentUser, db: DbSession):
    items, total = transaction_service.list_transactions(db, user.id, filters)
    return Page[TransactionRead](
        items=[TransactionRead.model_validate(i) for i in items], total=total,
        page=filters.page, page_size=filters.page_size,
    )


@router.post("/transactions", response_model=TransactionRead, status_code=status.HTTP_201_CREATED)
def create_transaction(data: TransactionCreate, user: CurrentUser, db: DbSession):
    return transaction_service.create_transaction(db, user.id, data)


@router.patch("/transactions/{transaction_id}", response_model=TransactionRead)
def update_transaction(transaction_id: uuid.UUID, data: TransactionUpdate, user: CurrentUser, db: DbSession):
    return transaction_service.update_transaction(db, user.id, transaction_id, data)


@router.delete("/transactions/{transaction_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_transaction(transaction_id: uuid.UUID, user: CurrentUser, db: DbSession):
    transaction_service.delete_transaction(db, user.id, transaction_id)
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.post("/transactions/own-transfers/detect", response_model=OwnTransfersResult)
def detect_own_transfers(user: CurrentUser, db: DbSession):
    """Mark imported rows that move money between the user's own accounts as transfers."""
    marked = own_transfers.mark_own_transfers(db, user.id)
    change_hooks.transactions_changed(db, user.id, {txn.transaction_date for txn in marked})
    return OwnTransfersResult(marked=len(marked))


@router.post("/transactions/{transaction_id}/not-transfer", status_code=status.HTTP_204_NO_CONTENT)
def unmark_transfer(transaction_id: uuid.UUID, user: CurrentUser, db: DbSession):
    """Undo an automatic own-transfer match so the rows count as income or expense again."""
    legs = own_transfers.unmark_transfer(db, user.id, transaction_id)
    change_hooks.transactions_changed(db, user.id, {leg.transaction_date for leg in legs}, legs)
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.post("/transactions/{transaction_id}/mark-transfer", status_code=status.HTTP_204_NO_CONTENT)
def mark_transfer(transaction_id: uuid.UUID, user: CurrentUser, db: DbSession):
    """Mark an imported row as money moved between the user's own accounts."""
    legs = own_transfers.mark_as_transfer(db, user.id, transaction_id)
    change_hooks.transactions_changed(db, user.id, {leg.transaction_date for leg in legs})
    return Response(status_code=status.HTTP_204_NO_CONTENT)


@router.post("/transfers", response_model=TransferRead, status_code=status.HTTP_201_CREATED)
def create_transfer(data: TransferCreate, user: CurrentUser, db: DbSession):
    group_id, outgoing, incoming = transaction_service.create_transfer(db, user.id, data)
    return TransferRead(
        transfer_group_id=group_id,
        outgoing=TransactionRead.model_validate(outgoing),
        incoming=TransactionRead.model_validate(incoming),
    )
